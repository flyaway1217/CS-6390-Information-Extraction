# CADE

My code runs successfully in lab2-1.

# Run

`python3 ner.py train.txt test.txt bothcon`

