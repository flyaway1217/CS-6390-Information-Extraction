# CADE

My code runs successfully in lab2-1.

# Run

``python3 dirt.py corpus.txt test.txt 5``

or just run the run.sh file:

``sh run.sh``

# Output

I did not align the scores for each path.
There is only one tab between the path and score.
