python3 dirt.py ./data/corpus.txt ./data/test.txt 5
